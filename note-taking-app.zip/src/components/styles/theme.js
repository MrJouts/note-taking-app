const theme = {
  colorPrimary: '#31303a',
  colorSecondary: '#6e6e71',
  colorDanger: '#ed4f32',
  colorWarning: '#ede04d',
  colorSuccess: '#15cd72',
  colorInfo: '#4bb1cf',
}

export default theme;