import styled from 'styled-components'

const InputColor = styled.input`
`
export default InputColor;