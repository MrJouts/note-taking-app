const ROUTE_NOTES = 'http://localhost:3001/notes/';
const ROUTE_COLORS = 'http://localhost:3001/colors/';

export { ROUTE_NOTES, ROUTE_COLORS };